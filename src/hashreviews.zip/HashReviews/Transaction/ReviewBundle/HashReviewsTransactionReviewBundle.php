<?php

namespace HashReviews\Transaction\ReviewBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HashReviewsTransactionReviewBundle extends Bundle
{
}
